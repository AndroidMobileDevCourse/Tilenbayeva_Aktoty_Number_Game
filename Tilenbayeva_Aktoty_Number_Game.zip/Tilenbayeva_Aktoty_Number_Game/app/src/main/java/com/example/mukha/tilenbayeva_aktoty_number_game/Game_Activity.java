package com.example.mukha.tilenbayeva_aktoty_number_game;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class Game_Activity extends AppCompatActivity {

    private TextView task,score;
    private Button less,equal,bigger;
    int max=10,min=1,answer,total=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_);

        task = (TextView) findViewById(R.id.textView);
        score = (TextView) findViewById(R.id.textView2);

        less = (Button) findViewById(R.id.button2);
        equal = (Button) findViewById(R.id.button3);
        bigger = (Button) findViewById(R.id.button4);

        less.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check(-1);
            }
        });

        equal.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check(0);
            }
        });

        bigger.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                check(1);
            }
        });
        this.Task();
    }

        private void check(int answer){
            if(answer == this.answer){
                this.total = this.total + 1;
            }else{
                this.total = this.total - 1;
            }

            this.score.setText("Score: " + this.total);
            this.Task();

        }

        private void Task(){
            Double a = this.RandomNumber();
            Double b = this.RandomNumber();
            this.answer = a.compareTo(b);
            this.task.setText(Math.round(a) + " ? " + Math.round(b));
        }

        private Double RandomNumber(){
            Random random = new Random();
            return (double) random.nextInt(max-min)+min;
        }

}
